<?php

require('connect.php');
header("Content-Type: application/json");
$v = json_decode(stripslashes(file_get_contents("php://input")));
// $d = count($v);
$url = $v->url;
$comment = $v->comment;
if($url != '' && $comment != ''){
    $sql = "INSERT INTO comments (username, email, url, comment) VALUES ('John', 'john@example.com', '$url', '$comment')";
    if ($conn->query($sql) === TRUE) {
        // echo "New record created successfully";
    } else {
        // echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
else{
    echo "Please Enter the Data!";
}
// var_export($d);
$conn->close();
?>
