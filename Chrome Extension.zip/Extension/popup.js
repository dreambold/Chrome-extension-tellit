var base_url = 'http://localhost/';

var upvote = document.getElementById('upvote');
$( document ).ready(function() {
	chrome.tabs.query({active : true, currentWindow: true}, function (tabs) {
	    var tab = (tabs.length === 0 ? tabs : tabs[0]);
	    var activeTabUrl = tab.url;
		read_comment(activeTabUrl, "true");
		
	});

});

function click(e) {
	chrome.tabs.query({active : true, currentWindow: true}, function (tabs) {
		var tab = (tabs.length === 0 ? tabs : tabs[0]);
		var activeTabUrl = tab.url;
		var newcomment = document.getElementById('newcomment').value;
		if(newcomment != '')
		send_request(activeTabUrl, newcomment);
	});
}
document.addEventListener('DOMContentLoaded', function () {
  var post = document.getElementById('post');
    post.addEventListener('click', click);
});

function send_request(current_url, newcomment){
// Sending and receiving data in JSON format using POST method
	var xhr = new XMLHttpRequest();
	var url = base_url + "add_comment.php";
	var data = {
		url: current_url,
		comment: newcomment
	};

	xhr.onreadystatechange = function () {
	    if (xhr.readyState === 4 && xhr.status === 200) {
	        // document.getElementById("tes").innerHTML = this.responseText;
	    }
	};
	xhr.open("POST", url, true);
	xhr.send(JSON.stringify(data));

		var str="<div class='comment_history'>"+newcomment+"<div style='height: 60px;' class='vote_div'>" + "<img class='upvote' src='images/upvote.png'>0<img class='downvote' src='images/downvote.png'>0</div></div>";
	
		$('#comment_history').append(str);
		var element = document.getElementById('comment_history'); 
		element.scrollTop = element.scrollHeight - element.clientHeight;
	
	document.getElementById('newcomment').value = '';
}

function read_comment(current_url, flag, currentHeight){
// Sending and receiving data in JSON format using POST method
	var xhr = new XMLHttpRequest();
	var url = base_url + "read_comment.php";
	var data = {
		url: current_url
	};

	xhr.onreadystatechange = function () {
	    if (xhr.readyState === 4 && xhr.status === 200) {
			// parse the response into JSON
			var comment = JSON.parse(this.responseText)['comment'];
			var id = JSON.parse(this.responseText)['id'];
			var upvote = JSON.parse(this.responseText)['upvote'];
			var downvote = JSON.parse(this.responseText)['downvote'];
			var count = comment.length;
			// var str ="<div  class='vote_div'>" + "<img class='upvote' src='images/upvote.png'>"+"<i>"+upvote[i]+"</i>"+"<img class='downvote' src='images/downvote.png'>"+"<i>"+downvote[i]+"</i>"+"</div>";
			for(var i=0; i< comment.length; i++){

				var str;
				
				if(upvote[i] > 0){
					str="<div class='comment_history'style=' overflow: hidden;word-wrap: break-word;' id='"+id[i]+"'>" +"<div  class='vote_div'><a style='cursor: pointer;'class='read_more'>Read More </a>" + "<img class='upvote' name='"+id[i]+"' src='images/upvote.png'>"+"<i class='upvote_num'>"+upvote[i]+"</i>"+"<img name='"+id[i]+"' class='downvote' src='images/downvote.png'>"+"<i class='downvote_num'>"+downvote[i]+"</i>"+"</div><b>"+comment[i]+"</b></div>";
				}
				else
					str="<div class='comment_history'style=' overflow: hidden;word-wrap: break-word;' id='"+id[i]+"'>" +"<div  class='vote_div'><a style='cursor: pointer;'class='read_more'>Read More </a>" + "<img class='upvote' name='"+id[i]+"' src='images/upvote.png'>"+"<i class='upvote_num'>"+upvote[i]+"</i>"+"<img name='"+id[i]+"' class='downvote' src='images/downvote.png'>"+"<i class='downvote_num'>"+downvote[i]+"</i>"+"</div>"+comment[i]+"</div>";

				
				$('#comment_history').append(str);

				var element = document.getElementById('comment_history'); 
				   element.scrollTop = element.scrollHeight - element.clientHeight;
			}
		
			$(".counter").append(count);
			$('.upvote').click(function(event){
				click_vote(event, 'true');
			})
			
			$('.downvote').click(function(event){
				click_vote(event,'false');
			})

			$('.read_more').click(function(event){
				readMore(event);
			})

			var comments = $('.comment_history');

			for(var i=0; i<comments.length; i++){

				if($(comments[i]).height()> 20){
					$(comments[i]).height('20px');
				}else{
					$($('.vote_div')[i]).children('a').remove();
					$(comments[i]).height('20px');
				}
			}
	    }
	};
	xhr.open("POST", url, true);
	xhr.send(JSON.stringify(data));
}

var show_ad_flag = true;

function showAd(){
	
	var deg;
	var img = document.getElementById('img');
	if(show_ad_flag){
		document.getElementById("show_text").style.display = 'none';
		document.getElementById("source_img").style.display = 'block';

        deg = -90 ;
	}
	else {
		document.getElementById("show_text").style.display = 'block';
		document.getElementById("source_img").style.display = 'none';
		deg = 0;
	}
	img.style.webkitTransform = 'rotate('+deg+'deg)'; 
	img.style.mozTransform    = 'rotate('+deg+'deg)'; 
	img.style.msTransform     = 'rotate('+deg+'deg)'; 
	img.style.oTransform      = 'rotate('+deg+'deg)'; 
	img.style.transform       = 'rotate('+deg+'deg)'; 

	show_ad_flag = !show_ad_flag;
}

document.addEventListener('DOMContentLoaded', function () {
	var post = document.getElementById('img');
	  post.addEventListener('click', showAd);
	document.getElementById('col1').addEventListener('click', set_color );
	document.getElementById('col2').addEventListener('click', set_color );
	document.getElementById('col3').addEventListener('click', set_color );
});

  function set_color(e){
	var set_color = e.target.id;
	switch(set_color) {
		case "col1":
				document.body.style.backgroundColor = "white";
				document.getElementById('post').style.backgroundColor = "white";
				document.body.style.borderColor = "black";
				$(".addclass").css("border-bottom-color", "black");
				$("#newcomment").css("border-color", "black");
				$("#newcomment").css("background-color", "white");

				document.getElementById('post').style.color = "black";
				document.body.style.color = "black"; 
		  break;
		case "col2":
				document.body.style.backgroundColor = "black";
				document.body.style.bordercolor = "white";
				$(".addclass").css("border-bottom-color", "white");
				$("#newcomment").css("border-color", "white");
				$("#newcomment").css("background-color", "black");
				$("#post").css("border-color", "white");
				$("#newcomment").css("color", "white");

				document.getElementById('post').style.backgroundColor = "black";
				document.getElementById('post').style.color = "white";
				document.body.style.color = "white"; 

		  break;
		case "col3":
				document.body.style.backgroundColor = "black";
				document.body.style.bordercolor = "red";
				$(".addclass").css("border-bottom-color", "red");
				$("#newcomment").css("border-color", "red");
				$("#newcomment").css("background-color", "black");
				$("#post").css("border-color", "red");
				$("#post").css("background-color", "black");
				$("#newcomment").css("color", "red");


				document.getElementById('post').style.color = "red";
				document.body.style.color = "red"; 
			
				break;
		default:
	  }
  }
//   up-vote, down-vote
  function click_vote(event, vote) {

	var activeTabUrl
	chrome.tabs.query({active : true, currentWindow: true}, function (tabs) {
		var tab = (tabs.length === 0 ? tabs : tabs[0]);
		activeTabUrl = tab.url;
	});

	var xhr = new XMLHttpRequest();
	var url = base_url + "vote.php";
	var data = {
		id: event.target.name,
		vote: vote
	};

	xhr.onreadystatechange = function () {
	    if (xhr.readyState === 4 && xhr.status === 200) {
			
			if(vote == 'true'){
			var currentValue = event.target.parentNode.children[1].innerHTML;
			event.target.parentNode.children[1].innerHTML = parseInt(currentValue) + 1;
			console.log(event.target.parentNode.text);
			}
			else {
			var currentValue = event.target.parentNode.children[3].innerHTML;

			event.target.parentNode.children[3].innerHTML = parseInt(currentValue) - 1;

			}


	    }
	};
	xhr.open("POST", url, true);
	xhr.send(JSON.stringify(data));

}

var readMoreFlag = true;
function readMore(event){
	if(readMoreFlag){
		event.target.innerHTML = "Read Less   &nbsp;";
		var ele = event.target.parentNode.parentNode;
		ele.style.height = 'auto';
	}else{
		event.target.innerHTML = "Read More   &nbsp;";
		var ele = event.target.parentNode.parentNode;
		ele.style.height = '20px';
	}
	readMoreFlag = !readMoreFlag;
	
}

$( function() {
	// $( "body" ).draggable();
	$( "html" ).resizable();

	
  } );


//-----------------------draggable---------------------
// $('#comment_history').css('position', 'absolute')
// dragElement(document.getElementById("#comment_history"));

// function dragElement(elmnt) {
//   var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;
//   if (document.getElementById(elmnt.id + "header")) {
//     // if present, the header is where you move the DIV from:
//     document.getElementById(elmnt.id + "header").onmousedown = dragMouseDown;
//   } else {
//     // otherwise, move the DIV from anywhere inside the DIV:
//     elmnt.onmousedown = dragMouseDown;
//   }

//   function dragMouseDown(e) {
//     e = e || window.event;
//     e.preventDefault();
//     // get the mouse cursor position at startup:
//     pos3 = e.clientX;
//     pos4 = e.clientY;
//     document.onmouseup = closeDragElement;
//     // call a function whenever the cursor moves:
//     document.onmousemove = elementDrag;
//   }

//   function elementDrag(e) {
//     e = e || window.event;
//     e.preventDefault();
//     // calculate the new cursor position:
//     pos1 = pos3 - e.clientX;
//     pos2 = pos4 - e.clientY;
//     pos3 = e.clientX;
//     pos4 = e.clientY;
//     // set the element's new position:
//     elmnt.style.top = (elmnt.offsetTop - pos2) + "px";
//     elmnt.style.left = (elmnt.offsetLeft - pos1) + "px";
//   }

//   function closeDragElement() {
//     // stop moving when mouse button is released:
//     document.onmouseup = null;
//     document.onmousemove = null;
//   }
// }
  


// chrome.windows.create({url: 'chrome://newtab'});