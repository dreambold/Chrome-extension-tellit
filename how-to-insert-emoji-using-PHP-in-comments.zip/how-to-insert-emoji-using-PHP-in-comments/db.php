<?php
   $conn = mysqli_connect("localhost","root","test","blog_samples");
   $conn->set_charset('utf8mb4');


?>