var base_url = 'http://localhost/';

var dt = new Date();
var time = dt.getHours();
//=========================================================================

// var docCookies = {
// 	getItem: function (sKey) {
// 		if (!sKey) { return null; }
// 		return decodeURIComponent(chrome.cookie.replace(new RegExp("(?:(?:^|.*;)\\s*" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=\\s*([^;]*).*$)|^.*$"), "$1")) || null;
// 	},
// 	setItem: function (sKey, sValue, vEnd, sPath, sDomain, bSecure) {
// 		if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) { return false; }
// 		var sExpires = "";
// 		if (vEnd) {
// 			switch (vEnd.constructor) {
// 				case Number:
// 					sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
// 					break;
// 				case String:
// 					sExpires = "; expires=" + vEnd;
// 					break;
// 				case Date:
// 					sExpires = "; expires=" + vEnd.toUTCString();
// 					break;
// 			}
// 		}
// 		chrome.cookie = encodeURIComponent(sKey) + "=" + encodeURIComponent(sValue) + sExpires + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "") + (bSecure ? "; secure" : "");
// 		return true;
// 	},
// 	removeItem: function (sKey, sPath, sDomain) {
// 		if (!this.hasItem(sKey)) { return false; }
// 		chrome.cookie = encodeURIComponent(sKey) + "=; expires=Thu, 01 Jan 1970 00:00:00 GMT" + (sDomain ? "; domain=" + sDomain : "") + (sPath ? "; path=" + sPath : "");
// 		return true;
// 	},
// 	hasItem: function (sKey) {
// 		if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) { return false; }
// 		return (new RegExp("(?:^|;\\s*)" + encodeURIComponent(sKey).replace(/[\-\.\+\*]/g, "\\$&") + "\\s*\\=")).test(document.cookie);
// 	},
// 	keys: function () {
// 		var aKeys = document.cookie.replace(/((?:^|\s*;)[^\=]+)(?=;|$)|^\s*|\s*(?:\=[^;]*)?(?:\1|$)/g, "").split(/\s*(?:\=[^;]*)?;\s*/);
// 		for (var nLen = aKeys.length, nIdx = 0; nIdx < nLen; nIdx++) { aKeys[nIdx] = decodeURIComponent(aKeys[nIdx]); }
// 		return aKeys;
// 	}
// };



//=======================Domcontent Loaded============================
document.addEventListener('DOMContentLoaded', function () {
	//=========================set time color mode============================================

	if (time >= 7 && time < 19) {
		document.body.style.backgroundColor = "white";
		document.getElementById('post').style.backgroundColor = "white";
		document.body.style.borderColor = "black";
		$(".addclass").css("border-bottom-color", "black");
		$("#newcomment").css("border-color", "black");
		$("#newcomment").css("background-color", "white");
		$(".emoji-wysiwyg-editor").css("border-color", "black");
		$("#username").css("background-color", "white");
		$("#username").css("border-color", "black");
		$("#username").css("color", "black");
		$(".emoji-wysiwyg-editor").css("color", "black");
		$("#post").css("border-color", "black");
		styleElement.appendChild(document.createTextNode("div ::-webkit-scrollbar{width:10px;} div::-webkit-scrollbar-track {box-shadow: inset 0 0 5px grey; border-radius: 5px;} div ::-webkit-scrollbar-thumb {background: grey;border-radius: 5px;} div::-webkit-scrollbar-thumb:hover {background: grey;} "));
		document.getElementById('post').style.color = "black";
		document.body.style.color = "black";
		document.getElementsByTagName("head")[0].appendChild(styleElement);


	}
	else {
		document.body.style.backgroundColor = "black";
		document.body.style.bordercolor = "#d9534f";
		$(".addclass").css("border-bottom-color", "#d9534f");
		$("#newcomment").css("border-color", "#d9534f");
		$("#newcomment").css("background-color", "black");
		$("#post").css("border-color", "#d9534f");
		$("#post").css("background-color", "black");
		$("#newcomment").css("color", "#d9534f");
		$(".emoji-wysiwyg-editor").css("border-color", "#d9534f");
		$("#username").css("background-color", "black");
		$("#username").css("border-color", "#d9534f");
		$("#username").css("color", "#d9534f");
		$(".emoji-wysiwyg-editor").css("color", "#d9534f");
		$(".emoji-items-wrap1").css("background-color", "black");
		styleElement.appendChild(document.createTextNode("div ::-webkit-scrollbar{width:9px;} div::-webkit-scrollbar-track {box-shadow: inset 0 0 5px #d9534f; border-radius: 5px;} div ::-webkit-scrollbar-thumb {background: #d9534f;border-radius: 5px;} div::-webkit-scrollbar-thumb:hover {background: #d9534f;} "));
		document.getElementById('post').style.color = "#d9534f";
		document.body.style.color = "#d9534f";
		document.getElementsByTagName("head")[0].appendChild(styleElement);
	}
	var post = document.getElementById('post');
	post.addEventListener('click', click);

	//======================resize popup=======================================

	var staticOffset = null;
	var textarea = $('#comment_history');
	$('.grippie').mousedown(startDrag);

	// grippie.insertAfter(textarea);

	function startDrag(e) {
		staticOffset = textarea.height() - e.pageY;
		textarea.css('opacity', 0.25);
		$(document).mousemove(performDrag).mouseup(endDrag);
		return false;
	}

	function performDrag(e) {
		textarea.height(Math.max(10, staticOffset + e.pageY) + 'px');
		return false;
	}
	//==============================enddrag=========================================
	function endDrag(e) {
		$(document).unbind('mousemove', performDrag).unbind('mouseup', endDrag);
		textarea.css('opacity', 1);
	}
	//=========================color_mode clicked=====================================
	var post = document.getElementById('img');
	post.addEventListener('click', showAd);
	document.getElementById('show_text').addEventListener('click', showAd);
	document.getElementById('col1').addEventListener('click', set_color);
	document.getElementById('col2').addEventListener('click', set_color);
	document.getElementById('col3').addEventListener('click', set_color);
	//==================================emojiPicker===============================================
	emojiPicker = new EmojiPicker({
		emojiable_selector: '[data-emojiable=true]',
		assetsPath: 'lib/img/',
		popupButtonClasses: 'fa fa-smile-o'
	});
	emojiPicker.discover();

	//==================user=====================
	var username = 'user' + Math.floor((Math.random() * 1000000) + 1);
	if (typeof localStorage.getItem('username') === 'null') {

		//string.indexOf(substring) !== -1
		localStorage.setItem('username', username);
		console.log('NO' + localStorage.getItem('username'));

		// console.log(isset(chrome.cookie))
	} else {
		// if (chrome.cookie.toString().indexOf('username') !== -1) {
		console.log('OK' + localStorage.getItem('username'));
		// }
	}
	// console.log(docCookies.getItem('username'))
});

//======================================================================
//========================clicked upvote===================================
var upvote = document.getElementById('upvote');
$(document).ready(function () {
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function (tabs) {
		var tab = (tabs.length === 0 ? tabs : tabs[0]);
		var activeTabUrl = tab.url;
		read_comment(activeTabUrl, "true");

	});

});
//========================================================================
//==========================after clicked post==============================
function click(e) {
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function (tabs) {
		var tab = (tabs.length === 0 ? tabs : tabs[0]);
		var activeTabUrl = tab.url;
		var newcomment = document.getElementById('newcomment').value;
		var username = document.getElementById('username').value;


		if (newcomment != '') {
			if (username == '') username = localStorage.getItem('username');
			else localStorage.setItem('username', username);
			send_request(activeTabUrl, newcomment, username);
		}
	});
	$('#first_comment').html('');
}

//=====================================================================
//=======================add new comment====================================

function send_request(current_url, newcomment, username) {
	// Sending and receiving data in JSON format using POST method
	var xhr = new XMLHttpRequest();
	var url = base_url + "add_comment.php";
	var data = {
		url: current_url,
		comment: newcomment,
		username: username
	};
	xhr.onreadystatechange = function () {
		if (xhr.readyState === 4 && xhr.status === 200) {
		}
	};
	xhr.open("POST", url, true);
	xhr.send(JSON.stringify(data));

	var str = "<div class='comment_history' style='word-wrap: break-word;'>" + newcomment + "<div class='vote_div'>" + "<img class='upvote' src='images/upvote.png'>0<img class='downvote' src='images/downvote.png'>0 &nbsp&nbsp&nbsp" + "<i style = 'color:#d9534f;'>" + username + "</i>" + "</div></div>";

	$('#comment_history').append(str);
	var element = document.getElementById('comment_history');
	element.scrollTop = element.scrollHeight - element.clientHeight;

	$('.emoji-wysiwyg-editor').html('');
	document.getElementById('username').value = '';
}
//======================================================================
//=========================Read comment========================================
function read_comment(current_url, flag, currentHeight) {
	// Sending and receiving data in JSON format using POST method
	var xhr = new XMLHttpRequest();
	var url = base_url + "read_comment.php";
	var data = {
		url: current_url
	};

	xhr.onreadystatechange = function () {
		if (xhr.readyState === 4 && xhr.status === 200) {
			var str = '';
			if (JSON.parse(this.responseText)['nodata'] == "false") {
				var comment = JSON.parse(this.responseText)['comment'];
				var username = JSON.parse(this.responseText)['username'];
				var id = JSON.parse(this.responseText)['id'];
				var upvote = JSON.parse(this.responseText)['upvote'];
				var downvote = JSON.parse(this.responseText)['downvote'];
				var count = comment.length;
				if (count != 0) {
					$('.fa-warning').css("display", "none");
				}
				else
					$('.fa-warning').css("display", "block");
				for (var i = 0; i < comment.length; i++) {

					if (upvote[i] > 0) {
						if (comment[i].length > 70) {
							var commen1 = comment[i].substr(0, 70);
							str += "<div class='comment_history' style=' overflow: hidden;word-wrap: break-word;' id='" + id[i] + "'>" + "<b class='readmore_bold'>" + commen1 + "</b>" + "<b class='readless_bold' style='display:none;'>" + comment[i] + "</b>" + "...&nbsp;&nbsp;" + "<span style='color: blue; border:solid blue 1px; cursor: pointer;'class='read_more'>ReadMore </span>" + "<div  class='vote_div'>" + "<img class='upvote' name='" + id[i] + "' src='images/upvote.png'>" + "<i class='upvote_num'>" + upvote[i] + "</i>" + "<img name='" + id[i] + "' class='downvote' src='images/downvote.png'>" + "<i class='downvote_num'>" + downvote[i] + "</i>" + "<i style = 'color:#d9534f;'>" + "&nbsp" + username[i] + "</i>" + "</div></div>";
						} else {
							str += "<div class='comment_history' style=' overflow: hidden;word-wrap: break-word;' id='" + id[i] + "'>" + "<b>" + comment[i] + "</b>" + "<div  class='vote_div'>" + "<img class='upvote' name='" + id[i] + "' src='images/upvote.png'>" + "<i class='upvote_num'>" + upvote[i] + "</i>" + "<img name='" + id[i] + "' class='downvote' src='images/downvote.png'>" + "<i class='downvote_num'>" + downvote[i] + "</i>" + "<i style = 'color:#d9534f;'>" + "&nbsp&nbsp&nbsp" + username[i] + "</i>" + "</div></div>";
						}
					}
					else if (upvote[i] == 0) {
						if (comment[i].length > 70) {
							var commen2 = comment[i].substr(0, 70);
							str += "<div class='comment_history' style=' overflow: hidden;word-wrap: break-word;' id='" + id[i] + "'>" + "<span class='readmore_bold'>" + commen2 + "</span><span class='readless_bold' style='display:none;'>" + comment[i] + "</span>" + "...&nbsp;&nbsp;" + "<span style='color: blue; border:solid blue 1px; cursor: pointer;'class='read_more'>ReadMore </span>" + "<div  class='vote_div'>" + "<img class='upvote' name='" + id[i] + "' src='images/upvote.png'>" + "<i class='upvote_num'>" + upvote[i] + "</i>" + "<img name='" + id[i] + "' class='downvote' src='images/downvote.png'>" + "<i class='downvote_num'>" + downvote[i] + "</i>" + "<i style = 'color:#d9534f;'>" + "&nbsp&nbsp&nbsp" + username[i] + "</i>" + "</div></div>";
						} else {
							str += "<div class='comment_history' style=' overflow: hidden;word-wrap: break-word;' id='" + id[i] + "'>" + "<span>" + comment[i] + "</span>" + "<div  class='vote_div'>" + "<img class='upvote' name='" + id[i] + "' src='images/upvote.png'>" + "<i class='upvote_num'>" + upvote[i] + "</i>" + "<img name='" + id[i] + "' class='downvote' src='images/downvote.png'>" + "<i class='downvote_num'>" + downvote[i] + "</i>" + "<i style = 'color:#d9534f;'>" + "&nbsp&nbsp&nbsp" + username[i] + "</i>" + "</div></div>";
						}
					}

				}

			}
			else {
				count = 0;
				str = "<h2 id='first_comment'>" + "Be the first comment!" + "</h2>"
			}
			$('#comment_history').append(str);
			var element = document.getElementById('comment_history');
			element.scrollTop = element.scrollHeight - element.clientHeight;

			//==========================append counter number==================================

			$(".counter").append(count);
			//============================event when click upvote==============================================
			$('.upvote').click(function (event) {
				click_vote(event, 'true');
			});
			//============================event when click downvote==============================================

			$('.downvote').click(function (event) {
				click_vote(event, 'false');
			});
			//============================event when click readmore==============================================

			$('.read_more').click(function (event) {
				readMore(event);
			});
		}
	};
	xhr.open("POST", url, true);
	xhr.send(JSON.stringify(data));
}

//================================================================================
//==============================Handle vote==============================================
function click_vote(event, vote) {

	var activeTabUrl;
	chrome.tabs.query({
		active: true,
		currentWindow: true
	}, function (tabs) {
		var tab = (tabs.length === 0 ? tabs : tabs[0]);
		activeTabUrl = tab.url;
	});

	var xhr = new XMLHttpRequest();
	var url = base_url + "vote.php";
	var data = {
		id: event.target.name,
		vote: vote
	};

	xhr.onreadystatechange = function () {
		if (xhr.readyState === 4 && xhr.status === 200) {

			if (vote == 'true') {
				var currentValue = event.target.parentNode.children[1].innerHTML;
				event.target.parentNode.children[1].innerHTML = parseInt(currentValue) + 1;
				console.log(event.target.parentNode.text);
			} else {
				var currentValue = event.target.parentNode.children[3].innerHTML;

				event.target.parentNode.children[3].innerHTML = parseInt(currentValue) + 1;

			}


		}
	};
	xhr.open("POST", url, true);
	xhr.send(JSON.stringify(data));

}
//=============================================================================
//==========================Advertise image click event=====================================
var show_ad_flag = true;
function showAd() {

	var deg;
	var img = document.getElementById('img');
	if (show_ad_flag) {
		document.getElementById("show_text").innerHTML = 'Hide Advertisment';
		// document.getElementById("hide_text").style.display = 'block';
		document.getElementById("source_img").style.display = 'block';

		deg = -90;
	} else {
		document.getElementById("show_text").innerHTML = 'Show Advertisment';
		// document.getElementById("hide_text").style.display = 'none';
		document.getElementById("source_img").style.display = 'none';
		deg = 0;
	}
	img.style.webkitTransform = 'rotate(' + deg + 'deg)';
	img.style.mozTransform = 'rotate(' + deg + 'deg)';
	img.style.msTransform = 'rotate(' + deg + 'deg)';
	img.style.oTransform = 'rotate(' + deg + 'deg)';
	img.style.transform = 'rotate(' + deg + 'deg)';

	show_ad_flag = !show_ad_flag;
}
//================================================================================
//==============================color mode =======================================
var styleElement = document.createElement("style");

function set_color(e) {
	var set_color = e.target.id;
	switch (set_color) {
		case "col1":
			document.body.style.backgroundImage = "";

			document.body.style.backgroundColor = "white";
			document.getElementById('post').style.backgroundColor = "white";
			document.body.style.borderColor = "black";
			$(".addclass").css("border-bottom-color", "black");
			$("#newcomment").css("border-color", "black");
			$("#newcomment").css("background-color", "white");
			$(".emoji-wysiwyg-editor").css("border-color", "black");
			$("#username").css("background-color", "white");
			$("#username").css("border-color", "black");
			$("#username").css("color", "black");
			$(".emoji-wysiwyg-editor").css("color", "black");
			$(".emoji-items-wrap1").css("background", "white");
			$("#mask").css("background-color", "rgb(105, 45, 45, 0)");

			$("#post").css("border-color", "black");
			styleElement.appendChild(document.createTextNode("div ::-webkit-scrollbar{width:9px;} div::-webkit-scrollbar-track {box-shadow: inset 0 0 5px grey; border-radius: 5px;} div ::-webkit-scrollbar-thumb {background: grey;border-radius: 5px;} div::-webkit-scrollbar-thumb:hover {background: grey;} "));
			document.getElementById('post').style.color = "black";
			document.body.style.color = "black";
			break;
		case "col2":
			document.body.style.backgroundColor = "#2c4600";
			document.body.style.backgroundImage = "url('images/troll_back.png')";
			if (time >= 7 && time < 19) {
				// styleElement.appendChild(document.createTextNode("body ::-webkit-mask-image{linear-gradient(to bottom, transparent 25%, black 75%);} body::mask-image {linear-gradient(to bottom, transparent 25%, black 75%);}"));
				// $('body').css({
				// 	"-webkit-mask-image": "linear-gradient(to bottom, transparent 25%, black 75%)",
				// 	"mask-image": "linear-gradient(to bottom, transparent 25%, black 75%)"
				// })
				$("#mask").css("background-color", "rgb(44, 70, 0, 0.8)");
				// $('.mask').css("background-color", "rbg(44, 70, 0, 0.7)");
			} else {
				$("#mask").css("background-color", "rgb(105, 45, 45, 0.8)");
				// $('#mask').css("background-color", "rbg(55, 70, 19, 0.7)");

			}


			document.body.style.bordercolor = "#ffffff";
			$(".addclass").css("border-bottom-color", "#ffffff");
			$("#newcomment").css("border-color", "#ffffff");
			$("#newcomment").css("background-color", "#2c4600");
			$("#post").css("border-color", "#ffffff");
			$("#newcomment").css("color", "#ffffff");
			$(".emoji-wysiwyg-editor").css("border-color", "#ffffff");
			$("#username").css("background-color", "rgb(44, 70, 0, 0)");
			$("#username").css("border-color", "#ffffff");
			$("#username").css("color", "#ffffff");
			$(".emoji-wysiwyg-editor").css("color", "#ffffff");
			$(".emoji-items-wrap1").css("background", "#2c4600");

			styleElement.appendChild(document.createTextNode("div ::-webkit-scrollbar{width:9px;} div::-webkit-scrollbar-track {box-shadow: inset 0 0 5px white; border-radius: 5px;} div ::-webkit-scrollbar-thumb {background: #ffffff;border-radius: 5px;} div::-webkit-scrollbar-thumb:hover {background: #ffffff;} "));

			document.getElementById('post').style.backgroundColor = "rgb(44, 70, 0, 0)";
			document.getElementById('post').style.color = "#ffffff";
			document.body.style.color = "#ffffff";
			break;
		case "col3":
			document.body.style.backgroundImage = "";

			document.body.style.backgroundColor = "black";
			document.body.style.bordercolor = "#d9534f";
			$(".addclass").css("border-bottom-color", "#d9534f");
			$("#newcomment").css("border-color", "#d9534f");
			$("#newcomment").css("background-color", "black");
			$("#post").css("border-color", "#d9534f");
			$("#post").css("background-color", "black");
			$("#newcomment").css("color", "#d9534f");
			$(".emoji-wysiwyg-editor").css("border-color", "#d9534f");
			$("#username").css("background-color", "black");
			$("#username").css("border-color", "#d9534f");
			$("#username").css("color", "#d9534f");
			$(".emoji-wysiwyg-editor").css("color", "#d9534f");
			$(".emoji-items-wrap1").css("background", "black");
			styleElement.appendChild(document.createTextNode("div ::-webkit-scrollbar{width:9px;} div::-webkit-scrollbar-track {box-shadow: inset 0 0 5px #d9534f; border-radius: 5px;} div ::-webkit-scrollbar-thumb {background: #d9534f;border-radius: 5px;} div::-webkit-scrollbar-thumb:hover {background: #d9534f;} "));
			document.getElementById('post').style.color = "#d9534f";
			document.body.style.color = "#d9534f";
			$("#mask").css("background-color", "rgb(105, 45, 45, 0)");

			break;
		default:
	}
	document.getElementsByTagName("head")[0].appendChild(styleElement);

}

//===================================================================================
//====================================Handle Readmore================================

var readMoreFlag = true;

function readMore(event) {
	if (readMoreFlag) {
		event.target.innerHTML = "ReadLess";
		event.target.parentNode.children[1].style.display = 'inline';
		event.target.parentNode.children[0].style.display = 'none';

	} else {
		event.target.innerHTML = "ReadMore";
		var ele = event.target.parentNode.parentNode;
		event.target.parentNode.children[1].style.display = 'none';
		event.target.parentNode.children[0].style.display = 'inline';
	}
	readMoreFlag = !readMoreFlag;
}


//======================================cookies===================
